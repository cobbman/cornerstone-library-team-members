<?php

/**
 * Definition: Team Member
 */

class CSL_Team_Member {

	public function ui() {
		return array(
			'title' => __( 'Team Member', '__x__' )
		);
	}
	
}