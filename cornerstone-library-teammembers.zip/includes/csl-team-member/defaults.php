<?php

/**
 * Default Values
 */

return array(
	'id'               => '',
	'class'            => '',
	'style'            => '',
	'name'             => '',
	'job_title'        => '',
	'highlight_color'  => '#000000',
	'member_image'     => 'http://placehold.it/200x250&text=Team+Member',
	'custom_open_text' => '',
	'member_content'   => ''
);