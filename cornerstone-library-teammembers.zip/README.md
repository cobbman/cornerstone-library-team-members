# Cornerstone Library: Team Members


Author: BigWilliam <hello@bigwilliam.com>

Adds a *Team Member* element to the [Cornerstone Page Builder](//theme.co/cornerstone) in WordPress. Displays photo of team member with a Modal pop-up when clicked on which shows additional information.

Download this file to install as a plugin in WordPress: <a href="https://github.com/bigwilliam/cornerstone-library-team-members/blob/master/cornerstone-library-teammembers.zip">Download as WordPress Plugin</a>

Keywords:

* WordPress
* Theme X
* Cornerstone